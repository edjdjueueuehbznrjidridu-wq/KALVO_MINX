"""Static contracts for boot diagnostics; device execution is separate."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = (ROOT / "main.py").read_text(encoding="utf-8")
TREE = ast.parse(SOURCE)


def test_boot_trace_is_installed_before_application_imports():
    assert "sys.excepthook = _early_crash_hook" in SOURCE
    assert '"main.py entered"' in SOURCE
    assert '"import-kivy"' in SOURCE
    assert '"import-apex-core"' in SOURCE
    assert '"module-imports-complete"' in SOURCE


def test_boot_trace_covers_database_and_ui_construction():
    for phase in (
        '"app-build-enter"', '"build-ui-database"',
        '"build-ui-database-ready"', '"build-dashboard"',
        '"build-navigation"', '"build-root-ready"',
    ):
        assert phase in SOURCE


def test_network_startup_is_deferred_until_after_first_frame():
    dashboard = next(n for n in TREE.body if isinstance(n, ast.ClassDef) and n.name == "DashboardScreen")
    on_enter = next(n for n in dashboard.body if isinstance(n, ast.FunctionDef) and n.name == "on_enter")
    assert "2.5" in ast.unparse(on_enter)


def test_boot_logs_do_not_include_secret_values():
    assert "startup-trace.log" in SOURCE
    assert "startup-crash.log" in SOURCE
